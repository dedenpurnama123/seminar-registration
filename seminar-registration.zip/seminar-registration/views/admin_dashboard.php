<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
include_once '../config/db.php';
include_once '../models/Registration.php';

$registration = new Registration($conn);
$registrations = $registration->getAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Admin Dashboard</h2>
    <table border="1">
<a href="manage_registration.php">Manage Registration</a>
<!-- Tabel peserta seminar tetap ada di sini -->

        <thead>
            <tr>
                <th>Email</th>
                <th>Name</th>
                <th>Institution</th>
                <th>Country</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($registrations as $row): ?>
            <tr>
                <td><?= $row['email'] ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['institution'] ?></td>
                <td><?= $row['country'] ?></td>
                <td><?= $row['address'] ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> | 
                    <a href="../controllers/registrationController.php?delete=<?= $row['id'] ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
