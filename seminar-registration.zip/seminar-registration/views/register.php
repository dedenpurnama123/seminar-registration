<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seminar Registration</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Seminar Registration</h2>
    <form action="../controllers/registrationController.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <label for="name">Name:</label>
        <input type="text" name="name" required><br><br>

        <label for="institution">Institution:</label>
        <input type="text" name="institution"><br><br>

        <label for="country">Country:</label>
        <input type="text" name="country" required><br><br>

        <label for="address">Address:</label>
        <textarea name="address" rows="4" cols="50"></textarea><br><br>

        <button type="submit" name="register">Register</button>
    </form>
</body>
</html>
