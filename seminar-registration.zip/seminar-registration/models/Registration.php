<?php
class Registration {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($email, $name, $institution, $country, $address) {
        $stmt = $this->conn->prepare("INSERT INTO registration (email, name, institution, country, address) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $email, $name, $institution, $country, $address);
        return $stmt->execute();
    }

    public function getAll() {
        $result = $this->conn->query("SELECT * FROM registration WHERE is_deleted = FALSE");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function update($id, $name, $institution, $country, $address) {
        $stmt = $this->conn->prepare("UPDATE registration SET name=?, institution=?, country=?, address=?, updated_at=NOW() WHERE id=?");
        $stmt->bind_param("ssssi", $name, $institution, $country, $address, $id);
        return $stmt->execute();
    }

    public function softDelete($id) {
        $stmt = $this->conn->prepare("UPDATE registration SET is_deleted=TRUE WHERE id=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
