<?php
$host = 'localhost';
$db = 'seminar_db';
$user = 'root';  // sesuaikan dengan username MySQL kamu
$pass = '';      // sesuaikan dengan password MySQL kamu

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
