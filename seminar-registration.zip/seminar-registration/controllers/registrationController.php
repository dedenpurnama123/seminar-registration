<?php
include_once '../config/db.php';
include_once '../models/Registration.php';

$conn = $GLOBALS['conn'];
$registration = new Registration($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $email = $_POST['email'];
        $name = $_POST['name'];
        $institution = $_POST['institution'];
        $country = $_POST['country'];
        $address = $_POST['address'];

        // Cek apakah email sudah ada
        $stmt = $conn->prepare("SELECT * FROM registration WHERE email=? AND is_deleted=FALSE");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "Email already exists!";
        } else {
            if ($registration->create($email, $name, $institution, $country, $address)) {
                echo "Registration successful!";
            } else {
                echo "Registration failed!";
            }
        }
    }

    if (isset($_POST['edit'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $institution = $_POST['institution'];
        $country = $_POST['country'];
        $address = $_POST['address'];

        if ($registration->update($id, $name, $institution, $country, $address)) {
            echo "Registration updated!";
        } else {
            echo "Update failed!";
        }
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    if ($registration->softDelete($id)) {
        echo "Registration deleted!";
    } else {
        echo "Delete failed!";
    }
}
?>
