<?php
session_start();
require '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mendapatkan data admin dari database
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Cek apakah admin ditemukan dan password cocok (gunakan MD5)
    if ($admin && md5($password) === $admin['password']) {
        $_SESSION['admin'] = $admin['id'];
        header("Location: ../views/admin_dashboard.php");
    } else {
        // Jika login gagal
        echo "Login failed!";
    }
}
?>
