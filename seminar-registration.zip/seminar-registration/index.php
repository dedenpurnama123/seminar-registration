<?php
header("Location: views/register.php");
?>
